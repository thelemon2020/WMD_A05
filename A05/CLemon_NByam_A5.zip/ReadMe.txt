Multi Client Chat Program

By Chris Lemon and Nick Byam

Thanks for downloading our client-server chat program, We hope you like it! Here's a couple helpful tips to get the best mileage
out of it!

1. VERY IMPORTANT, if attempting to chat with friends across the network, you need to make sure to port forward the port 23000 on your
   device because that is the port the server listens on for incoming communications.

   For client's listening abilities, you must have port 35000 - 350XX forwarded. each client listens on a different port to avoid
   clients on the same machine messing with eachother's abilities to listen for incoming messages from your friends.
   We recommend forwarding ports 35000 - 35050. That gives you the opportunity to have 50 friends on at once! Wow!
   Failure to forward your ports will cause the server to crash, so this step is VERY IMPORTANT!

2. There is a super user available but only to those in the know. When starting the server and connecting with a client for the first
   time on your own computer with a friend, a log will be created that stores user names and hashed passwords. It is created in the same
   folder as the server, so be sure to put the server somewhere safe!
   The super user will be registered automatically, and has the username: admin
																	  PW: admin
   Using this super user will allow you to shutdown the server safely.

Thank you again! Happy chatting!